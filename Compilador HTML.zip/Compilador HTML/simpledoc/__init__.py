"""
SimpleDoc - Un compilador para un lenguaje de marcado simplificado

Este módulo implementa un compilador para un lenguaje de marcado simplificado
que analiza documentos, valida su sintaxis y los transforma a HTML.
"""

__version__ = '1.0.0'
